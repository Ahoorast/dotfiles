package main

func Solution(f func(uint8) uint8, inp uint32) uint32 {
	// TODO
	return 0
}
