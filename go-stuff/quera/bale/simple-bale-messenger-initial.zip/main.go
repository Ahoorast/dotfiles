package main

type Bale interface {
	AddUser(username string, isBot bool) (int, error)
	AddChat(chatname string, isGroup bool, creator int, admins []int) (int, error)
	SendMessage(userId, chatId int, text string) (int, error)
	SendLike(userId, messageId int) error
	GetNumberOfLikes(messageId int) (int, error)
	SetChatAdmin(chatId, userId int) error
	GetLastMessage(chatId int) (string, int, error)
	GetLastUserMessage(userId int) (string, int, error)
}

type BaleImpl struct {
	// TODO: Implement
}

func NewBaleImpl() *BaleImpl {
	// TODO: Implement
	return &BaleImpl{}
}

func (bi *BaleImpl) AddUser(username string, isBot bool) (int, error) {
	// TODO: Implement
	return 0, nil
}

func (bi *BaleImpl) AddChat(chatname string, isGroup bool, creator int, admins []int) (int, error) {
	// TODO: Implement
	return 0, nil
}

func (bi *BaleImpl) SendMessage(userId, chatId int, text string) (int, error) {
	// TODO: Implement
	return 0, nil
}

func (bi *BaleImpl) SendLike(userId, messageId int) error {
	// TODO: Implement
	return nil
}

func (bi *BaleImpl) GetNumberOfLikes(messageId int) (int, error) {
	// TODO: Implement
	return 0, nil
}

func (bi *BaleImpl) SetChatAdmin(chatId, userId int) error {
	// TODO: Implement
	return nil
}

func (bi *BaleImpl) GetLastMessage(chatId int) (string, int, error) {
	// TODO: Implement
	return "", 0, nil
}

func (bi *BaleImpl) GetLastUserMessage(userId int) (string, int, error) {
	// TODO: Implement
	return "", 0, nil
}
