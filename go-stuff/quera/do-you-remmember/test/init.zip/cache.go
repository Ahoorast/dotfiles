package cache

type Cache struct {
}

type CacheServerConnection struct {
}

func InitCache() *Cache {
	// TODO
	return nil
}

func (cache *Cache) Connect(name string) *CacheClientConnection {
	request := make(chan CacheRequest)
	response := make(chan CacheResponse)

	//https://knowyourmeme.com/memes/trade-offer
	serverConn := &CacheServerConnection{
		// TODO
	}
	clientConn := &CacheClientConnection{
		snd: request,
		rcv: response,
	}

	//cache.connsMutex.Lock()
	//cache.conns = append(cache.conns, serverConn)
	//cache.connsMutex.Unlock()

	return clientConn
}
