package main

func GuessMyNumber(game Game) string {
	_ = game.CheckNumber(0)
	return ""
}
