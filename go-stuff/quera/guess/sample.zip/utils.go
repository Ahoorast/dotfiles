package main

type Game interface {
	CheckNumber(n int) string
}
