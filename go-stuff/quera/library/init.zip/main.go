package library

type Library struct {
}

func NewLibrary(capacity int) *Library {
	// TODO
	return nil
}

func (library *Library) AddBook(name string) string {
	// TODO
	return ""
}

func (library *Library) BorrowBook(bookName, personName string) string {
	// TODO
	return ""
}

func (library *Library) ReturnBook(bookName string) string {
	// TODO
	return ""
}
